#include <stdio.h>

int main()
{
int a, b, c, d;

a = getchar();
b = 0;
if (a > 100)
{
 d = a/b;
}
else
{
c = b/a;
}

return 0;
}
