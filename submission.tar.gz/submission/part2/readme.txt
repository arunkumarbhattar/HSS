If you want to reproduce crash --> naviagate to the crashes directory, open the file, and spli the data equivalently into N-parts, if your program accepts N inputs.
Also, the flag required to pass No Of inputs is -k and not -b. 
