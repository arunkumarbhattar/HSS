#undef   PKGDATADIR
#define  PKGDATADIR "/usr/local/share/autogen"

#define  DEFINING 1
#include "autoopts/project.h"
#include "opts.c"
#include "getdefs.h"
#include "proto.h"
#include "getdefs.c"
#include "gdemit.c"
#include "gdinit.c"
