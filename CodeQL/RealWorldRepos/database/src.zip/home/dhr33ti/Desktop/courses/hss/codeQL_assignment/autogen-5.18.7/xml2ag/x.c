#undef   PKGDATADIR
#define  PKGDATADIR "/usr/share/autogen"

#define  DEFINING 1
#include "autoopts/project.h"
#include "xmlopts.c"
#include "fork.c"
#include "xml2ag.c"
