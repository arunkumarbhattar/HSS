#undef   PKGDATADIR
#define  PKGDATADIR "/usr/share/autogen"

#define  DEFINING 1
#include "autoopts/project.h"
#include "opts.h"
#include "columns.c"
#include "opts.c"
